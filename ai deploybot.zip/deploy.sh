#!/bin/bash

# Ensure the deployment folder exists and is empty
mkdir -p deployed_site
rm -rf deployed_site/*

# Check if uploaded.zip exists in the current directory
if [ ! -f "uploaded.zip" ]; then
  echo "Error: uploaded.zip not found."
  exit 1
fi

# Extract the uploaded ZIP file into the deployment folder
unzip uploaded.zip -d deployed_site

# Move into the deployed site folder
cd deployed_site || exit

# Start a simple HTTP server on port 8080 in the background
python3 -m http.server 8080 &
echo "Deployment successful! Site is served on port 8080."