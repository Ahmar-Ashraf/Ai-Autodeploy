async function uploadZip() {
    const fileInput = document.getElementById("zipFile");
    const file = fileInput.files[0];
    if (!file) {
        document.getElementById("result").innerText = "Please select a ZIP file.";
        return;
    }
    
    // Read the file as a base64-encoded string
    const reader = new FileReader();
    reader.onload = async function() {
        // Remove the data URL header (e.g., "data:application/zip;base64,")
        const base64Data = reader.result.split(',')[1];
        const response = await fetch("/.netlify/functions/deploy_zip", {
            method: "POST",
            body: base64Data
        });
        const result = await response.text();
        document.getElementById("result").innerText = result;
    };
    reader.readAsDataURL(file);
}

async function deployRepo() {
    const repoUrl = document.getElementById("repoUrl").value;
    if (!repoUrl) {
        document.getElementById("result").innerText = "Please enter a repository URL.";
        return;
    }
    
    const response = await fetch("/.netlify/functions/deploy_repo", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ repoUrl })
    });
    const result = await response.text();
    document.getElementById("result").innerText = result;
}