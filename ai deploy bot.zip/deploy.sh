#!/bin/bash

# Exit immediately if a command exits with a non-zero status
set -e

echo "Starting deployment on Netlify..."

# Ensure dependencies are installed
echo "Installing dependencies..."
npm install

# Build the project
echo "Building the project..."
npm run build

# Deploy using Netlify CLI
echo "Deploying to Netlify..."
netlify deploy --prod

echo "Deployment successful!"