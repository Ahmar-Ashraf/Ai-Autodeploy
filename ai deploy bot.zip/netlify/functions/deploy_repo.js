const { exec } = require("child_process");
const path = require("path");

exports.handler = async (event, context) => {
  // Allow only POST requests
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }

  // Expect a JSON payload containing the repository URL
  let repoUrl;
  try {
    const data = JSON.parse(event.body);
    repoUrl = data.repoUrl;
  } catch (err) {
    return { statusCode: 400, body: "Invalid request body. Expecting JSON." };
  }

  if (!repoUrl) {
    return { statusCode: 400, body: "Repository URL not provided." };
  }

  // Define the directory to clone the repository into
  const cloneDir = "/tmp/deploy_repo";

  // Build the clone command. Remove any previous clone first.
  const cloneCommand = `rm -rf ${cloneDir} && git clone ${repoUrl} ${cloneDir}`;

  return new Promise((resolve, reject) => {
    exec(cloneCommand, { cwd: "/tmp" }, (error, stdout, stderr) => {
      if (error) {
        resolve({ statusCode: 500, body: `Error cloning repository: ${stderr}` });
      } else {
        // If additional deployment steps are needed, add them here.
        resolve({ statusCode: 200, body: `Repository cloned successfully.\n${stdout}` });
      }
    });
  });
};