const { execFile } = require("child_process");
const fs = require("fs");
const path = require("path");

exports.handler = async (event, context) => {
  // Allow only POST requests
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }

  // Expect the body to contain the base64-encoded ZIP file data.
  const base64Zip = event.body;
  if (!base64Zip) {
    return { statusCode: 400, body: "No ZIP file data provided." };
  }

  // Write the file to a temporary location (/tmp is writable in Netlify Functions)
  const zipPath = "/tmp/uploaded.zip";
  fs.writeFileSync(zipPath, Buffer.from(base64Zip, "base64"));

  // Call the deploy.sh script located in the root directory
  const scriptPath = path.join(__dirname, "..", "deploy.sh");
  return new Promise((resolve, reject) => {
    execFile(scriptPath, { cwd: "/tmp" }, (error, stdout, stderr) => {
      if (error) {
        resolve({ statusCode: 500, body: `Error during deployment: ${stderr}` });
      } else {
        resolve({ statusCode: 200, body: stdout });
      }
    });
  });
};