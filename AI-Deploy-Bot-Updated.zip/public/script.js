async function uploadFile() {
    let file = document.getElementById("zipFile").files[0];
    let formData = new FormData();
    formData.append("file", file);

    let response = await fetch("/.netlify/functions/deploy_zip", {
        method: "POST",
        body: formData
    });

    let result = await response.json();
    document.getElementById("zipResult").innerText = result.url || "Error: " + result.error;
}

async function deployRepo() {
    let repoUrl = document.getElementById("repoUrl").value;

    let response = await fetch("/.netlify/functions/deploy_repo", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ repo_url: repoUrl })
    });

    let result = await response.json();
    document.getElementById("repoResult").innerText = result.url || "Error: " + result.error;
}