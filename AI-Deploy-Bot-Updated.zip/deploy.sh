#!/bin/bash

# Ensure deployment folder exists
mkdir -p deployed_site
rm -rf deployed_site/*

# Extract uploaded ZIP file
unzip uploaded.zip -d deployed_site

# Move into deployed site folder
cd deployed_site

# Start a simple HTTP server
python3 -m http.server 8080 &
echo "Deployment successful! Website is live at: http://localhost:8080"