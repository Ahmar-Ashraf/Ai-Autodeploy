const { spawn } = require("child_process");
const fetch = require("node-fetch");

const OPENAI_API_KEY = "your_openai_api_key";

async function fixErrors(errorLogs) {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
            "Authorization": `Bearer ${OPENAI_API_KEY}`,
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            model: "gpt-4",
            messages: [{ role: "system", content: `Fix this deployment error: ${errorLogs}` }]
        })
    });

    const data = await response.json();
    return data.choices[0].message.content;
}

exports.handler = async (event) => {
    try {
        let deployProcess = spawn("bash", ["deploy.sh"]);

        deployProcess.on("exit", async (code) => {
            if (code !== 0) {
                let fixedCode = await fixErrors(`Deployment failed with exit code ${code}`);
                console.log("AI Fixed Code: ", fixedCode);
            }
        });

        return {
            statusCode: 200,
            body: JSON.stringify({ url: "https://your-replit-url.repl.co" })
        };
    } catch (error) {
        return { statusCode: 500, body: JSON.stringify({ error: error.message }) };
    }
};